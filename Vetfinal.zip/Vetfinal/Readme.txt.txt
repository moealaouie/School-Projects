Veterinary Clinic


Program designed to meet all your clinic needs. The user can select from a variety of options in the menu. They can schedule an appointment for grooming, neutering, and a wellness exam.
every user can have as many pets added to their account. the clinic offers services to certain mammals and reptiles(cats,dogs, and lizards). if any information was entered incorrectly the user can edit their data in the menu.
the user can also check billing information and mark their payments as paid. all persons and pets are recorded in files for future use.
